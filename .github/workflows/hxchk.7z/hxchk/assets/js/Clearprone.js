 function clearText() {
document.getElementById("declined_cc").innerHTML = "";
                     }
                     

                     
                     

